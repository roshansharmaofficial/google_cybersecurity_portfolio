# Portfolio-Activity-Apply-Filters-to-SQL-Queries
From Google Cybersecurity Professional Certificate Program on Coursera
